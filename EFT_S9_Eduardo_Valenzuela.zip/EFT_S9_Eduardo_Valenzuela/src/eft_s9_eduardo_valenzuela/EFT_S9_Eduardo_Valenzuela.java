package eft_s9_eduardo_valenzuela;

/** Evaluación Final Transversal
 *
 * @ Eduardo Valenzuela Magaña
 */

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Scanner;

public class EFT_S9_Eduardo_Valenzuela {

    // Variables globales para el total de entradas
    static final int TOTAL_VIP = 30;
    static final int TOTAL_PALCO = 50;
    static final int TOTAL_PLATEA_BAJA = 60;
    static final int TOTAL_PLATEA_ALTA = 80;
    static final int TOTAL_GALERIA = 100;

    // Variables globales para las entradas vendidas
    static int vendidasVIP = 0;
    static int vendidasPalco = 0;
    static int vendidasPlateaBaja = 0;
    static int vendidasPlateaAlta = 0;
    static int vendidasGaleria = 0;

    // Variables globales de reserva de entradas
    static int reservasVIP = 0;
    static int reservasPalco = 0;
    static int reservasPlateaBaja = 0;
    static int reservasPlateaAlta = 0;
    static int reservasGaleria = 0;

    // Variables globales para los precios de cada tipo de entrada
    static final double PRECIO_VIP = 40000;
    static final double PRECIO_PALCO = 30000;
    static final double PRECIO_PLATEA_BAJA = 20000;
    static final double PRECIO_PLATEA_ALTA = 15000;
    static final double PRECIO_GALERIA = 10000;

    // Arreglos para almacenar los asientos
    static int[] seatIDs;
    static String[] seatTypes;
    static boolean[] seatReserved;
    static boolean[] seatSold;

    // Listas para almacenar clientes
    static ArrayList<Integer> customerIDs = new ArrayList<>();
    static ArrayList<String> customerNames = new ArrayList<>();
    static ArrayList<String> customerTypes = new ArrayList<>();

    // Listas para almacenar ventas
    static ArrayList<Integer> saleIDs = new ArrayList<>();
    static ArrayList<Integer> saleCustomerIDs = new ArrayList<>();
    static ArrayList<Integer> saleSeatIDs = new ArrayList<>();
    static ArrayList<Double> salePrices = new ArrayList<>();
    static ArrayList<String> compras = new ArrayList<>();

    // Listas para almacenar reservas
    static ArrayList<Integer> reservationIDs = new ArrayList<>();
    static ArrayList<Integer> reservationCustomerIDs = new ArrayList<>();
    static ArrayList<Integer> reservationSeatIDs = new ArrayList<>();

    // Lista para manejar descuentos y promociones
    static ArrayList<String> discountTypes = new ArrayList<>();
    static ArrayList<Double> discountValues = new ArrayList<>();
    
//****************************MAIN**************************************************************************
    
    
    public static void main(String[] args) throws UnsupportedEncodingException {
        Scanner scanner = new Scanner(new InputStreamReader(System.in, "UTF-8"));
        inicializarAsientos(); // Inicializamos los asientos
        inicializarDescuentos(); // Inicializamos los descuentos
        boolean continuar = true; // Variable de control para el bucle

        // Menú para seleccionar y vender entradas
        while (continuar) { // Mientras continuar sea true, el menú seguirá ejecutándose
            System.out.println("\nSeleccione una opción:");
            System.out.println("1. Comprar entrada");
            System.out.println("2. Reservar entrada");
            System.out.println("3. Modificar compra realizada");
            System.out.println("4. Salir");

            //**************** validar opción del menú  *************************************************************

            int opcion = 0; // Variable opción inicializada en cero
            boolean opcionValida = false;
            while (!opcionValida) {
                if (scanner.hasNextInt()) {
                    opcion = scanner.nextInt();
                    scanner.nextLine(); // Consumir el salto de línea
                    if (opcion >= 1 && opcion <= 4) {
                        opcionValida = true;
                    } else {
                        System.out.println("Opción no válida. Por favor, ingresa un número entero de 1 a 4.");
                    }
                } else {
                    System.out.println("Entrada no válida. Por favor, ingresa un número entero de 1 a 4.");
                    scanner.nextLine(); // Consumir la entrada inválida
                }
            }
            //************************  LLAMADO A MÉTODOS  *******************************************************************************

            switch (opcion) {
                case 1:
                    seleccionTipoEntrada(scanner); // Llamada para comprar entradas
                    break;
                case 2:
                    reservarEntradas(scanner); // Llamada para hacer reservas
                    break;
                case 3:
                    modificarCompra(scanner); // Llamada para modificar una compra realizada
                    break;
                case 4:
                    continuar = false; // Cambia la variable a false para detener el bucle
                    System.out.println("Gracias por usar el sistema de venta de entradas.");
                    break;
            }
        }
    }

    // *******************************  INICIALIZACIÓN DE VARIABLES, ARREGLOS Y LISTAS  *********************************************************************************************************

    // Método para inicializar los asientos

    public static void inicializarAsientos() {
        int totalAsientos = TOTAL_VIP + TOTAL_PALCO + TOTAL_PLATEA_BAJA + TOTAL_PLATEA_ALTA + TOTAL_GALERIA;
        seatIDs = new int[totalAsientos];
        seatTypes = new String[totalAsientos];
        seatReserved = new boolean[totalAsientos];
        seatSold = new boolean[totalAsientos];

        int idAsiento = 1;

        // Inicializar asientos VIP
        for (int i = 0; i < TOTAL_VIP; i++) {
            seatIDs[i] = idAsiento++;
            seatTypes[i] = "VIP";
            seatReserved[i] = false;
            seatSold[i] = false;
        }

        // Inicializar asientos Palco
        for (int i = TOTAL_VIP; i < TOTAL_VIP + TOTAL_PALCO; i++) {
            seatIDs[i] = idAsiento++;
            seatTypes[i] = "Palco";
            seatReserved[i] = false;
            seatSold[i] = false;
        }

        // Inicializar asientos Platea Baja
        for (int i = TOTAL_VIP + TOTAL_PALCO; i < TOTAL_VIP + TOTAL_PALCO + TOTAL_PLATEA_BAJA; i++) {
            seatIDs[i] = idAsiento++;
            seatTypes[i] = "Platea Baja";
            seatReserved[i] = false;
            seatSold[i] = false;
        }

        // Inicializar asientos Platea Alta
        for (int i = TOTAL_VIP + TOTAL_PALCO + TOTAL_PLATEA_BAJA; i < TOTAL_VIP + TOTAL_PALCO + TOTAL_PLATEA_BAJA + TOTAL_PLATEA_ALTA; i++) {
            seatIDs[i] = idAsiento++;
            seatTypes[i] = "Platea Alta";
            seatReserved[i] = false;
            seatSold[i] = false;
        }

        // Inicializar asientos Galería
        for (int i = TOTAL_VIP + TOTAL_PALCO + TOTAL_PLATEA_BAJA + TOTAL_PLATEA_ALTA; i < totalAsientos; i++) {
            seatIDs[i] = idAsiento++;
            seatTypes[i] = "Galería";
            seatReserved[i] = false;
            seatSold[i] = false;
        }
    }

    // Método para inicializar descuentos y promociones

    public static void inicializarDescuentos() {
        discountTypes.add("Niños");
        discountValues.add(0.10); // 10% de descuento

        discountTypes.add("Mujeres");
        discountValues.add(0.20); // 20% de descuento

        discountTypes.add("Estudiantes");
        discountValues.add(0.15); // 15% de descuento

        discountTypes.add("Tercera Edad");
        discountValues.add(0.25); // 25% de descuento
    }

    
    // ******** MÉTODOS ***************************************************************************************************************************

    // Método para comprar entradas

   public static void seleccionTipoEntrada(Scanner scanner) {

    double precioTotal = 0; // Variable para acumular el valor total de las entradas compradas
    boolean seguirComprando = true;
    ArrayList<String> compras = new ArrayList<>(); // Lista para almacenar las compras de esta sesión

    // Solicitar datos del cliente

    System.out.println("Ingrese su nombre:");
    String nombre = scanner.nextLine();
    System.out.println("Ingrese su ID de cliente (cédula):");

    int idCliente = 0;
    boolean opcionValida = false;
    while (!opcionValida) {
        if (scanner.hasNextInt()) {
            idCliente = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea
            opcionValida = true;
        } else {
            System.out.println("Entrada no válida. Por favor, ingrese un número de ID válido.");
            scanner.nextLine(); // Consumir la entrada inválida
        }
    }

    // Verificar si el cliente existe
    int clienteIndex = customerIDs.indexOf(idCliente);
    String tipoCliente = "";
    double descuento = 0;

    if (clienteIndex == -1) {
        // Cliente no encontrado, registrar nuevo cliente
        System.out.println("Cliente no encontrado. Procediendo a registrar nuevo cliente.");

        // Solicitar tipo de cliente
        System.out.println("Seleccione el tipo de cliente:");
        for (int i = 0; i < discountTypes.size(); i++) {
            System.out.println((i + 1) + ". " + discountTypes.get(i) + " (" + (discountValues.get(i) * 100) + "% de descuento)");
        }

        int tipoClienteOpcion = 0;
        opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                tipoClienteOpcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                if (tipoClienteOpcion >= 1 && tipoClienteOpcion <= discountTypes.size()) {
                    opcionValida = true;
                } else {
                    System.out.println("Opción no válida. Por favor, ingrese un número entre 1 y " + discountTypes.size() + ".");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número entre 1 y " + discountTypes.size() + ".");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        tipoCliente = discountTypes.get(tipoClienteOpcion - 1);
        descuento = discountValues.get(tipoClienteOpcion - 1);

        // Agregar cliente a las listas
        customerIDs.add(idCliente);
        customerNames.add(nombre);
        customerTypes.add(tipoCliente);

        clienteIndex = customerIDs.size() - 1; // El índice del cliente es el último en las listas

        System.out.println("Nuevo cliente registrado exitosamente.");
    } else {
        // Cliente encontrado, obtener su tipo y descuento
        System.out.println("Cliente encontrado: " + customerNames.get(clienteIndex));
        tipoCliente = customerTypes.get(clienteIndex);
        int descuentoIndex = discountTypes.indexOf(tipoCliente);
        if (descuentoIndex != -1) {
            descuento = discountValues.get(descuentoIndex);
        }
    }

    while (seguirComprando) {
        // Menú para seleccionar el tipo de entrada
        System.out.println("Seleccione el tipo de entrada:");
        System.out.println("1. VIP (Precio: $" + PRECIO_VIP + ")");
        System.out.println("2. Palco (Precio: $" + PRECIO_PALCO + ")");
        System.out.println("3. Platea Baja (Precio: $" + PRECIO_PLATEA_BAJA + ")");
        System.out.println("4. Platea Alta (Precio: $" + PRECIO_PLATEA_ALTA + ")");
        System.out.println("5. Galería (Precio: $" + PRECIO_GALERIA + ")");

        int tipoEntrada = 0;
        opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                tipoEntrada = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                if (tipoEntrada >= 1 && tipoEntrada <= 5) {
                    opcionValida = true;
                } else {
                    System.out.println("Opción no válida. Por favor, ingrese un número entre 1 y 5.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número entre 1 y 5.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        double precioEntrada = 0;
        String tipoEntradaStr = "";

        switch (tipoEntrada) {
            case 1:
                tipoEntradaStr = "VIP";
                precioEntrada = PRECIO_VIP;
                break;
            case 2:
                tipoEntradaStr = "Palco";
                precioEntrada = PRECIO_PALCO;
                break;
            case 3:
                tipoEntradaStr = "Platea Baja";
                precioEntrada = PRECIO_PLATEA_BAJA;
                break;
            case 4:
                tipoEntradaStr = "Platea Alta";
                precioEntrada = PRECIO_PLATEA_ALTA;
                break;
            case 5:
                tipoEntradaStr = "Galería";
                precioEntrada = PRECIO_GALERIA;
                break;
        }

        // Aplicar descuento
        precioEntrada = precioEntrada - (precioEntrada * descuento);

        // Mostrar asientos disponibles del tipo seleccionado
        System.out.println("Asientos " + tipoEntradaStr + " (Disponibles: ID, Vendidos: XX, Reservados: RR):");
        int contador = 0;
        for (int i = 0; i < seatIDs.length; i++) {
            if (seatTypes[i].equals(tipoEntradaStr)) {
                if (!seatSold[i] && !seatReserved[i]) {
                    System.out.print(seatIDs[i] + "\t");
                } else if (seatSold[i]) {
                    System.out.print("XX\t");
                } else if (seatReserved[i]) {
                    System.out.print("RR\t");
                }
                contador++;
                if (contador % 10 == 0) {
                    System.out.println();
                }
            }
        }
        System.out.println();

        // Solicitar al usuario que ingrese el ID del asiento que desea comprar
        int asientoSeleccionadoID = 0;
        opcionValida = false;
        while (!opcionValida) {
            System.out.println("Ingrese el ID del asiento que desea comprar:");
            if (scanner.hasNextInt()) {
                asientoSeleccionadoID = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                opcionValida = true;
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número de ID válido.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        // Buscar el asiento seleccionado
        int asientoIndex = -1;
        for (int i = 0; i < seatIDs.length; i++) {
            if (seatIDs[i] == asientoSeleccionadoID && seatTypes[i].equals(tipoEntradaStr)) {
                asientoIndex = i;
                break;
            }
        }

        if (asientoIndex == -1) {
            System.out.println("El asiento seleccionado no existe o no corresponde al tipo seleccionado.");
        } else if (seatSold[asientoIndex]) {
            System.out.println("El asiento seleccionado ya ha sido vendido (XX).");
        } else if (seatReserved[asientoIndex]) {
            System.out.println("El asiento seleccionado está reservado (RR).");
        } else {
            // Actualizar el estado del asiento
            seatSold[asientoIndex] = true;

            // Actualizar contador de entradas vendidas
            switch (tipoEntrada) {
                case 1:
                    vendidasVIP++;
                    break;
                case 2:
                    vendidasPalco++;
                    break;
                case 3:
                    vendidasPlateaBaja++;
                    break;
                case 4:
                    vendidasPlateaAlta++;
                    break;
                case 5:
                    vendidasGaleria++;
                    break;
            }

            // Crear registro de venta
            int idVenta = saleIDs.size() + 1;
            saleIDs.add(idVenta);
            saleCustomerIDs.add(idCliente);
            saleSeatIDs.add(seatIDs[asientoIndex]);
            salePrices.add(precioEntrada);

            // Detalle de la compra
            String compraDetalle = String.format("Entrada %s, Asiento: %d, Precio: $%,.2f", tipoEntradaStr, asientoSeleccionadoID, precioEntrada);
            compras.add(compraDetalle);

            System.out.println("Entrada " + tipoEntradaStr + " vendida. Asiento: " + asientoSeleccionadoID + ". Precio final: $" + String.format("%,.2f", precioEntrada));

            // Acumular el valor de la entrada en el precio total
            precioTotal += precioEntrada;
        }

        // Preguntar si desea seguir comprando más entradas
        boolean entradaValida = false;
        int seguir = 0;

        while (!entradaValida) {
            System.out.println("¿Desea comprar otra entrada? (1. Sí, 2. No)");
            if (scanner.hasNextInt()) {
                seguir = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                if (seguir == 1 || seguir == 2) {
                    entradaValida = true;
                } else {
                    System.out.println("Opción no válida. Por favor, ingrese 1 para Sí o 2 para No.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese 1 para Sí o 2 para No.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        if (seguir != 1) {
            seguirComprando = false;
        }
    }

    // Obtener el índice del cliente en la lista customerIDs (ya lo tenemos como clienteIndex)
    if (clienteIndex != -1) {
        // Obtener el nombre del cliente
        String nombreCliente = customerNames.get(clienteIndex);

        // Imprimir el encabezado de la boleta
        System.out.println("=======================================");
        System.out.println("           BOLETA DE COMPRA            ");
        System.out.println("=======================================");
        System.out.println("Nombre del Cliente: " + nombreCliente);

        // Imprimir cada compra realizada
        for (int i = 0; i < compras.size(); i++) {
            System.out.println((i + 1) + ". " + compras.get(i));
        }

        // Imprimir el total
        System.out.println("------------------------------------------------------------");
        System.out.println("Precio Total: $" + String.format("%,.2f", precioTotal));
        System.out.println("============================================================");
    } else {
        System.out.println("Cliente no encontrado. No se puede imprimir la boleta.");
    }
}


    // Método para reservar entradas
    public static void reservarEntradas(Scanner scanner) {
        // Solicitar datos del cliente
        System.out.println("Ingrese su nombre:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese su ID de cliente (cédula):");

        int idCliente = 0;
        boolean opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                idCliente = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                opcionValida = true;
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número de ID válido.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        // Verificar si el cliente existe
        int clienteIndex = customerIDs.indexOf(idCliente);
        String tipoCliente = "";
        if (clienteIndex == -1) {
            // Cliente no encontrado, registrar nuevo cliente
            System.out.println("Cliente no encontrado. Procediendo a registrar nuevo cliente.");

            // Solicitar tipo de cliente
            System.out.println("Seleccione el tipo de cliente:");
            for (int i = 0; i < discountTypes.size(); i++) {
                System.out.println((i + 1) + ". " + discountTypes.get(i));
            }

            int tipoClienteOpcion = 0;
            opcionValida = false;
            while (!opcionValida) {
                if (scanner.hasNextInt()) {
                    tipoClienteOpcion = scanner.nextInt();
                    scanner.nextLine(); // Consumir el salto de línea
                    if (tipoClienteOpcion >= 1 && tipoClienteOpcion <= discountTypes.size()) {
                        opcionValida = true;
                    } else {
                        System.out.println("Opción no válida. Por favor, ingrese un número entre 1 y " + discountTypes.size() + ".");
                    }
                } else {
                    System.out.println("Entrada no válida. Por favor, ingrese un número entre 1 y " + discountTypes.size() + ".");
                    scanner.nextLine(); // Consumir la entrada inválida
                }
            }

            tipoCliente = discountTypes.get(tipoClienteOpcion - 1);

            // Agregar cliente a las listas
            customerIDs.add(idCliente);
            customerNames.add(nombre);
            customerTypes.add(tipoCliente);

            clienteIndex = customerIDs.size() - 1; // El índice del cliente es el último en las listas

            System.out.println("Nuevo cliente registrado exitosamente.");
        } else {
            // Cliente encontrado
            System.out.println("Cliente encontrado: " + customerNames.get(clienteIndex));
            tipoCliente = customerTypes.get(clienteIndex);
        }

        boolean seguirReservando = true;
        while (seguirReservando) {
            // Menú para seleccionar el tipo de entrada a reservar
            System.out.println("Seleccione el tipo de entrada que desea reservar:");
            System.out.println("1. VIP");
            System.out.println("2. Palco");
            System.out.println("3. Platea Baja");
            System.out.println("4. Platea Alta");
            System.out.println("5. Galería");

            int tipoEntrada = 0;
            opcionValida = false;
            while (!opcionValida) {
                if (scanner.hasNextInt()) {
                    tipoEntrada = scanner.nextInt();
                    scanner.nextLine(); // Consumir el salto de línea
                    if (tipoEntrada >= 1 && tipoEntrada <= 5) {
                        opcionValida = true;
                    } else {
                        System.out.println("Opción no válida. Por favor, ingrese un número entre 1 y 5.");
                    }
                } else {
                    System.out.println("Entrada no válida. Por favor, ingrese un número entre 1 y 5.");
                    scanner.nextLine(); // Consumir la entrada inválida
                }
            }

            String tipoEntradaStr = "";

            switch (tipoEntrada) {
                case 1:
                    tipoEntradaStr = "VIP";
                    break;
                case 2:
                    tipoEntradaStr = "Palco";
                    break;
                case 3:
                    tipoEntradaStr = "Platea Baja";
                    break;
                case 4:
                    tipoEntradaStr = "Platea Alta";
                    break;
                case 5:
                    tipoEntradaStr = "Galería";
                    break;
            }

            // Mostrar asientos disponibles del tipo seleccionado
            System.out.println("Asientos " + tipoEntradaStr + " (Disponibles: ID, Vendidos: XX, Reservados: RR):");
            int contador = 0;
            for (int i = 0; i < seatIDs.length; i++) {
                if (seatTypes[i].equals(tipoEntradaStr)) {
                    if (!seatSold[i] && !seatReserved[i]) {
                        System.out.print(seatIDs[i] + "\t");
                    } else if (seatSold[i]) {
                        System.out.print("XX\t");
                    } else if (seatReserved[i]) {
                        System.out.print("RR\t");
                    }
                    contador++;
                    if (contador % 10 == 0) {
                        System.out.println();
                    }
                }
            }
            System.out.println();

            // Solicitar al usuario que ingrese el ID del asiento que desea reservar
            int asientoSeleccionadoID = 0;
            opcionValida = false;
            while (!opcionValida) {
                System.out.println("Ingrese el ID del asiento que desea reservar:");
                if (scanner.hasNextInt()) {
                    asientoSeleccionadoID = scanner.nextInt();
                    scanner.nextLine(); // Consumir el salto de línea
                    opcionValida = true;
                } else {
                    System.out.println("Entrada no válida. Por favor, ingrese un número de ID válido.");
                    scanner.nextLine(); // Consumir la entrada inválida
                }
            }

            // Buscar el asiento seleccionado
            int asientoIndex = -1;
            for (int i = 0; i < seatIDs.length; i++) {
                if (seatIDs[i] == asientoSeleccionadoID && seatTypes[i].equals(tipoEntradaStr)) {
                    asientoIndex = i;
                    break;
                }
            }

            if (asientoIndex == -1) {
                System.out.println("El asiento seleccionado no existe o no corresponde al tipo seleccionado.");
            } else if (seatSold[asientoIndex]) {
                System.out.println("El asiento seleccionado ya ha sido vendido (XX).");
            } else if (seatReserved[asientoIndex]) {
                System.out.println("El asiento seleccionado está reservado (RR).");
            } else {
                // Actualizar el estado del asiento
                seatReserved[asientoIndex] = true;

                // Actualizar contador de reservas
                switch (tipoEntrada) {
                    case 1:
                        reservasVIP++;
                        break;
                    case 2:
                        reservasPalco++;
                        break;
                    case 3:
                        reservasPlateaBaja++;
                        break;
                    case 4:
                        reservasPlateaAlta++;
                        break;
                    case 5:
                        reservasGaleria++;
                        break;
                }

                // Crear registro de reserva
                int idReserva = reservationIDs.size() + 1;
                reservationIDs.add(idReserva);
                reservationCustomerIDs.add(idCliente);
                reservationSeatIDs.add(seatIDs[asientoIndex]);

                System.out.println("Asiento " + asientoSeleccionadoID + " reservado exitosamente. ID de reserva: " + idReserva);
            }

            // Preguntar si desea seguir reservando más entradas
            boolean entradaValida = false;
            int seguir = 0;

            while (!entradaValida) {
                System.out.println("¿Desea reservar otra entrada? (1. Sí, 2. No)");
                if (scanner.hasNextInt()) {
                    seguir = scanner.nextInt();
                    scanner.nextLine(); // Consumir el salto de línea
                    if (seguir == 1 || seguir == 2) {
                        entradaValida = true;
                    } else {
                        System.out.println("Opción no válida. Por favor, ingrese 1 para Sí o 2 para No.");
                    }
                } else {
                    System.out.println("Entrada no válida. Por favor, ingrese 1 para Sí o 2 para No.");
                    scanner.nextLine(); // Consumir la entrada inválida
                }
            }

            if (seguir != 1) {
                seguirReservando = false;
            }
        }
    }

    // Método para modificar una compra
    public static void modificarCompra(Scanner scanner) {
        // Solicitar datos del cliente
        System.out.println("Ingrese su ID de cliente (cédula):");

        int idCliente = 0;
        boolean opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                idCliente = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                opcionValida = true;
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número de ID válido.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        // Verificar si el cliente existe
        int clienteIndex = customerIDs.indexOf(idCliente);
        if (clienteIndex == -1) {
            System.out.println("Cliente no encontrado.");
            return;
        } else {
            System.out.println("Cliente encontrado: " + customerNames.get(clienteIndex));
        }

        // Mostrar opciones de modificación
        System.out.println("Seleccione la acción que desea realizar:");
        System.out.println("1. Eliminar compra");
        System.out.println("2. Cambiar tipo de entrada");
        System.out.println("3. Activar reserva");
        System.out.println("4. Volver al menú principal");

        int opcion = 0;
        opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                if (opcion >= 1 && opcion <= 4) {
                    opcionValida = true;
                } else {
                    System.out.println("Opción no válida. Por favor, ingrese un número entre 1 y 4.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número entre 1 y 4.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        switch (opcion) {
            case 1:
                eliminarCompra(scanner, idCliente);
                break;
            case 2:
                cambiarTipoEntrada(scanner, idCliente);
                break;
            case 3:
                activarReserva(scanner, idCliente);
                break;
            case 4:
                // Volver al menú principal
                return;
        }
    }

    // Método para eliminar una compra
    public static void eliminarCompra(Scanner scanner, int idCliente) {
        // Listar las compras realizadas por el cliente
        ArrayList<Integer> comprasDelCliente = new ArrayList<>();
        System.out.println("Compras realizadas por el cliente:");
        for (int i = 0; i < saleCustomerIDs.size(); i++) {
            if (saleCustomerIDs.get(i).equals(idCliente)) {
                comprasDelCliente.add(i);
                System.out.println("ID de venta: " + saleIDs.get(i) +
                        ", Asiento: " + saleSeatIDs.get(i) +
                        ", Precio: $" + salePrices.get(i));
            }
        }

        if (comprasDelCliente.isEmpty()) {
            System.out.println("El cliente no tiene compras registradas.");
            return;
        }

        // Solicitar al usuario que seleccione una compra para eliminar
        System.out.println("Ingrese el ID de venta que desea eliminar:");
        int idVenta = 0;
        boolean opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                idVenta = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                if (saleIDs.contains(idVenta) && saleCustomerIDs.get(saleIDs.indexOf(idVenta)).equals(idCliente)) {
                    opcionValida = true;
                } else {
                    System.out.println("El ID de venta no es válido o no pertenece al cliente. Por favor, ingrese un ID de venta válido.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número de ID de venta válido.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        int ventaIndex = saleIDs.indexOf(idVenta);

        // Obtener el asiento asociado a la venta
        int asientoID = saleSeatIDs.get(ventaIndex);
        int asientoIndex = -1;
        for (int i = 0; i < seatIDs.length; i++) {
            if (seatIDs[i] == asientoID) {
                asientoIndex = i;
                break;
            }
        }

        if (asientoIndex != -1) {
            // Liberar el asiento
            seatSold[asientoIndex] = false;
            seatReserved[asientoIndex] = false;

            // Actualizar contadores
            String tipoAsiento = seatTypes[asientoIndex];
            switch (tipoAsiento) {
                case "VIP":
                    vendidasVIP--;
                    break;
                case "Palco":
                    vendidasPalco--;
                    break;
                case "Platea Baja":
                    vendidasPlateaBaja--;
                    break;
                case "Platea Alta":
                    vendidasPlateaAlta--;
                    break;
                case "Galería":
                    vendidasGaleria--;
                    break;
            }
        }

        // Remover la venta de las listas
        saleIDs.remove(ventaIndex);
        saleCustomerIDs.remove(ventaIndex);
        saleSeatIDs.remove(ventaIndex);
        salePrices.remove(ventaIndex);

        System.out.println("Compra eliminada exitosamente.");
    }

    // Método para cambiar el tipo de entrada
    public static void cambiarTipoEntrada(Scanner scanner, int idCliente) {
        // Listar las compras realizadas por el cliente
        ArrayList<Integer> comprasDelCliente = new ArrayList<>();
        System.out.println("Compras realizadas por el cliente:");
        for (int i = 0; i < saleCustomerIDs.size(); i++) {
            if (saleCustomerIDs.get(i).equals(idCliente)) {
                comprasDelCliente.add(i);
                System.out.println("ID de venta: " + saleIDs.get(i) +
                        ", Asiento: " + saleSeatIDs.get(i) +
                        ", Precio: $" + salePrices.get(i));
            }
        }

        if (comprasDelCliente.isEmpty()) {
            System.out.println("El cliente no tiene compras registradas.");
            return;
        }

        // Solicitar al usuario que seleccione una compra para modificar
        System.out.println("Ingrese el ID de venta que desea modificar:");
        int idVenta = 0;
        boolean opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                idVenta = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                if (saleIDs.contains(idVenta) && saleCustomerIDs.get(saleIDs.indexOf(idVenta)).equals(idCliente)) {
                    opcionValida = true;
                } else {
                    System.out.println("El ID de venta no es válido o no pertenece al cliente. Por favor, ingrese un ID de venta válido.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número de ID de venta válido.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        int ventaIndex = saleIDs.indexOf(idVenta);

        // Proceder con el cambio de tipo de entrada
        System.out.println("Seleccione el nuevo tipo de entrada:");
        System.out.println("1. VIP");
        System.out.println("2. Palco");
        System.out.println("3. Platea Baja");
        System.out.println("4. Platea Alta");
        System.out.println("5. Galería");

        int nuevoTipoEntrada = 0;
        opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                nuevoTipoEntrada = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                if (nuevoTipoEntrada >= 1 && nuevoTipoEntrada <= 5) {
                    opcionValida = true;
                } else {
                    System.out.println("Opción no válida. Por favor, ingrese un número entre 1 y 5.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número entre 1 y 5.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        String nuevoTipoEntradaStr = "";

        switch (nuevoTipoEntrada) {
            case 1:
                nuevoTipoEntradaStr = "VIP";
                break;
            case 2:
                nuevoTipoEntradaStr = "Palco";
                break;
            case 3:
                nuevoTipoEntradaStr = "Platea Baja";
                break;
            case 4:
                nuevoTipoEntradaStr = "Platea Alta";
                break;
            case 5:
                nuevoTipoEntradaStr = "Galería";
                break;
        }

        // Mostrar asientos disponibles del nuevo tipo
        System.out.println("Asientos " + nuevoTipoEntradaStr + " (Disponibles: ID, Vendidos: XX, Reservados: RR):");
        int contador = 0;
        for (int i = 0; i < seatIDs.length; i++) {
            if (seatTypes[i].equals(nuevoTipoEntradaStr)) {
                if (!seatSold[i] && !seatReserved[i]) {
                    System.out.print(seatIDs[i] + "\t");
                } else if (seatSold[i]) {
                    System.out.print("XX\t");
                } else if (seatReserved[i]) {
                    System.out.print("RR\t");
                }
                contador++;
                if (contador % 10 == 0) {
                    System.out.println();
                }
            }
        }
        System.out.println();

        // Solicitar al usuario que ingrese el ID del nuevo asiento
        int nuevoAsientoID = 0;
        opcionValida = false;
        while (!opcionValida) {
            System.out.println("Ingrese el ID del nuevo asiento que desea:");
            if (scanner.hasNextInt()) {
                nuevoAsientoID = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                opcionValida = true;
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número de ID válido.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }

        // Buscar un asiento disponible del nuevo tipo
        int nuevoAsientoIndex = -1;
        for (int i = 0; i < seatIDs.length; i++) {
            if (seatIDs[i] == nuevoAsientoID && seatTypes[i].equals(nuevoTipoEntradaStr)) {
                nuevoAsientoIndex = i;
                break;
            }
        }

        if (nuevoAsientoIndex == -1) {
            System.out.println("El asiento seleccionado no existe o no corresponde al tipo seleccionado.");
            return;
        } else if (seatSold[nuevoAsientoIndex]) {
            System.out.println("El asiento seleccionado ya ha sido vendido (XX).");
            return;
        } else if (seatReserved[nuevoAsientoIndex]) {
            System.out.println("El asiento seleccionado está reservado (RR).");
            return;
        } else {
            // Liberar el asiento anterior
            int asientoIDAnterior = saleSeatIDs.get(ventaIndex);
            int asientoIndexAnterior = -1;
            for (int i = 0; i < seatIDs.length; i++) {
                if (seatIDs[i] == asientoIDAnterior) {
                    asientoIndexAnterior = i;
                    break;
                }
            }
            if (asientoIndexAnterior != -1) {
                seatSold[asientoIndexAnterior] = false;
                seatReserved[asientoIndexAnterior] = false;

                // Actualizar contadores
                String tipoAsientoAnterior = seatTypes[asientoIndexAnterior];
                switch (tipoAsientoAnterior) {
                    case "VIP":
                        vendidasVIP--;
                        break;
                    case "Palco":
                        vendidasPalco--;
                        break;
                    case "Platea Baja":
                        vendidasPlateaBaja--;
                        break;
                    case "Platea Alta":
                        vendidasPlateaAlta--;
                        break;
                    case "Galería":
                        vendidasGaleria--;
                        break;
                }
            }

            // Asignar nuevo asiento
            seatSold[nuevoAsientoIndex] = true;
            saleSeatIDs.set(ventaIndex, seatIDs[nuevoAsientoIndex]);

            // Actualizar contadores para el nuevo tipo de asiento
            switch (nuevoTipoEntradaStr) {
                case "VIP":
                    vendidasVIP++;
                    break;
                case "Palco":
                    vendidasPalco++;
                    break;
                case "Platea Baja":
                    vendidasPlateaBaja++;
                    break;
                case "Platea Alta":
                    vendidasPlateaAlta++;
                    break;
                case "Galería":
                    vendidasGaleria++;
                    break;
            }

            // Actualizar precio (aplicando el descuento correspondiente)
            int clienteIndex = customerIDs.indexOf(idCliente);
            String tipoCliente = customerTypes.get(clienteIndex);
            double descuento = 0;
            int descuentoIndex = discountTypes.indexOf(tipoCliente);
            if (descuentoIndex != -1) {
                descuento = discountValues.get(descuentoIndex);
            }

            double precioEntrada = 0;
            switch (nuevoTipoEntrada) {
                case 1:
                    precioEntrada = PRECIO_VIP - (PRECIO_VIP * descuento);
                    break;
                case 2:
                    precioEntrada = PRECIO_PALCO - (PRECIO_PALCO * descuento);
                    break;
                case 3:
                    precioEntrada = PRECIO_PLATEA_BAJA - (PRECIO_PLATEA_BAJA * descuento);
                    break;
                case 4:
                    precioEntrada = PRECIO_PLATEA_ALTA - (PRECIO_PLATEA_ALTA * descuento);
                    break;
                case 5:
                    precioEntrada = PRECIO_GALERIA - (PRECIO_GALERIA * descuento);
                    break;
            }

            salePrices.set(ventaIndex, precioEntrada);

            System.out.println("Tipo de entrada cambiado exitosamente. Nuevo asiento: " + nuevoAsientoID + ". Nuevo precio: $" + precioEntrada);
        }
    }

    // Método para activar una reserva
    public static void activarReserva(Scanner scanner, int idCliente) {
        // Verificar si el cliente tiene reservas
        ArrayList<Integer> reservasDelCliente = new ArrayList<>();
        System.out.println("Reservas activas del cliente:");
        for (int i = 0; i < reservationCustomerIDs.size(); i++) {
            if (reservationCustomerIDs.get(i).equals(idCliente)) {
                reservasDelCliente.add(i);
                System.out.println("ID de reserva: " + reservationIDs.get(i) +
                        ", Asiento: " + reservationSeatIDs.get(i));
            }
        }

        if (reservasDelCliente.isEmpty()) {
            System.out.println("El cliente no tiene reservas activas.");
            return;
        }

        // Solicitar al usuario que seleccione una reserva para activar
        System.out.println("Ingrese el ID de reserva que desea activar:");
        int idReserva = 0;
        boolean opcionValida = false;
        while (!opcionValida) {
            if (scanner.hasNextInt()) {
                idReserva = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea
                int reservaIndex = reservationIDs.indexOf(idReserva);
                if (reservaIndex != -1 && reservationCustomerIDs.get(reservaIndex).equals(idCliente)) {
                    opcionValida = true;

                    // Proceder a activar la reserva
                    int asientoReservadoID = reservationSeatIDs.get(reservaIndex);

                    // Crear una nueva venta
                    int idVenta = saleIDs.size() + 1;
                    saleIDs.add(idVenta);
                    saleCustomerIDs.add(idCliente);
                    saleSeatIDs.add(asientoReservadoID);

                    // Calcular precio con descuento
                    int clienteIndex = customerIDs.indexOf(idCliente);
                    String tipoCliente = customerTypes.get(clienteIndex);
                    double descuento = 0;
                    int descuentoIndex = discountTypes.indexOf(tipoCliente);
                    if (descuentoIndex != -1) {
                        descuento = discountValues.get(descuentoIndex);
                    }

                    // Determinar el tipo de asiento
                    int asientoIndex = -1;
                    String tipoAsiento = "";
                    for (int i = 0; i < seatIDs.length; i++) {
                        if (seatIDs[i] == asientoReservadoID) {
                            asientoIndex = i;
                            tipoAsiento = seatTypes[i];
                            seatReserved[i] = false;
                            seatSold[i] = true;
                            break;
                        }
                    }

                    double precioEntrada = 0;
                    switch (tipoAsiento) {
                        case "VIP":
                            precioEntrada = PRECIO_VIP - (PRECIO_VIP * descuento);
                            vendidasVIP++;
                            reservasVIP--;
                            break;
                        case "Palco":
                            precioEntrada = PRECIO_PALCO - (PRECIO_PALCO * descuento);
                            vendidasPalco++;
                            reservasPalco--;
                            break;
                        case "Platea Baja":
                            precioEntrada = PRECIO_PLATEA_BAJA - (PRECIO_PLATEA_BAJA * descuento);
                            vendidasPlateaBaja++;
                            reservasPlateaBaja--;
                            break;
                        case "Platea Alta":
                            precioEntrada = PRECIO_PLATEA_ALTA - (PRECIO_PLATEA_ALTA * descuento);
                            vendidasPlateaAlta++;
                            reservasPlateaAlta--;
                            break;
                        case "Galería":
                            precioEntrada = PRECIO_GALERIA - (PRECIO_GALERIA * descuento);
                            vendidasGaleria++;
                            reservasGaleria--;
                            break;
                    }

                    salePrices.add(precioEntrada);

                    // Remover la reserva
                    reservationIDs.remove(reservaIndex);
                    reservationCustomerIDs.remove(reservaIndex);
                    reservationSeatIDs.remove(reservaIndex);

                    System.out.println("Reserva activada exitosamente. Asiento: " + asientoReservadoID + ". Precio: $" + precioEntrada);

                } else {
                    System.out.println("El ID de reserva no es válido o no pertenece al cliente. Por favor, ingrese un ID de reserva válido.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingrese un número de ID de reserva válido.");
                scanner.nextLine(); // Consumir la entrada inválida
            }
        }
    }
    
    
}
